"use strict";
// Redesign of Page //
function change()
{
    alert("Redesign"); // This will redesign my entire template //
    
    let f = document.getElementById('changecolor1');
    f.style.opacity="0.20"; // This will grade out my images by 80% //
    f.style.transform="rotate(180deg)"; // This will rotate my image by 180 degrees // 
    f.style.border="dashed"; // This will put a border around my images and it will be a dashed border //
    
    let g = document.getElementById('changecolor2');
    g.style.opacity="0.20"; // This will grade out my images by 80% //
    g.style.transform="rotate(180deg)"; // This will rotate my image by 180 degrees // 
    g.style.border="dashed"; // This will put a border around my images and it will be a dashed border //
    
    let h = document.getElementById('changecolor3');
    h.style.opacity="0.20"; // This will grade out my images by 80% //
    h.style.transform="rotate(180deg)"; // This will rotate my image by 180 degrees // 
    h.style.border="dashed"; // This will put a border around my images and it will be a dashed border //
    
    let i = document.getElementById('changecolor4');
    i.style.opacity="0.20"; // This will grade out my images by 80% //
    i.style.transform="rotate(180deg)"; // This will rotate my image by 180 degrees // 
    i.style.border="dashed"; // This will put a border around my images and it will be a dashed border //
    
    let j = document.getElementById('changecolor5');
    j.style.opacity="0.20"; // This will grade out my images by 80% //
    j.style.transform="rotate(180deg)"; // This will rotate my image by 180 degrees // 
    j.style.border="dashed"; // This will put a border around my images and it will be a dashed border //
    
    let k = document.getElementById('changecolor6');
    k.style.opacity="0.20"; // This will grade out my images by 80% //
    k.style.transform="rotate(180deg)"; // This will rotate my image by 180 degrees // 
    k.style.border="dashed"; // This will put a border around my images and it will be a dashed border //
    
    let m= document.getElementById('projects');
    m.style.backgroundColor="blue"; // This will set the background colour to blue //
    m.style.textAlign="right"; // This will display all text on the right side of the screen //
    m.style.fontSize="30px"; // This will enlarge the text to a font size of 30 pixels //
    
    let n = document.getElementById('flipimage1');
    n.style.transform="rotate(90deg)"; // This will rotate my image by 90 degrees // 
    
    let o = document.getElementById('flipimage2');
    o.style.transform="rotate(90deg)"; // This will rotate my image by 90 degrees // 
    
    let p = document.getElementById('flipimage3');
    p.style.transform="rotate(90deg)"; // This will rotate my image by 90 degrees // 
    
    let q = document.getElementById('flipimage4');
    q.style.transform="rotate(90deg)"; // This will rotate my image by 90 degrees // 
    
    let r = document.getElementById('flipimage5');
    r.style.transform="rotate(90deg)"; // This will rotate my image by 90 degrees // 
    
    let s = document.getElementById('flipimage6');
    s.style.transform="rotate(90deg)"; // This will rotate my image by 90 degrees //  
    
    let t = document.getElementById('flipimage7');
    t.style.transform="rotate(90deg)"; // This will rotate my image by 90 degrees // 
    
    let u = document.getElementById('flipimage8');
    u.style.transform="rotate(90deg)"; // This will rotate my image by 90 degrees // 
    
    let v = document.getElementById('changeAbout');
    v.style.backgroundColor="purple";
    v.style.transform="rotate(180deg)"; // This will rotate my image by 180 degrees // 
    
    var w = document.getElementById('removeContact');
    removeContact.remove(); // This will remove the contact section of my template //
}

// Adding 10 new paragraph elements to home page //
function AddElements()
{
    var para1 = document.createElement("P1");
    para1.innerText="Each house in the Projects section is designed to our customers requests/needs and is carefully managed by our special team of architects.";
    document.body.appendChild(para1);
    
    var para2 = document.createElement("P2");
    para2.innerText="We are located in Berlin, Germany and are fully qualified in structure building.";
    document.body.appendChild(para2);
    
    var para3 = document.createElement("P3");
    para3.innerText="We are 100% commited to ensuring we finish ahead of schedule for our clients appreciation.";
    document.body.appendChild(para3);
    
    var para4 = document.createElement("P4");
    para4.innerText="We cater for any project size, large or small!";
    document.body.appendChild(para4);
    
    var para5 = document.createElement("P5");
    para5.innerText="We agree a set fee with our clients so that there are no surprise totals added on top of the agreed fee.";
    document.body.appendChild(para5);
    
    var para6 = document.createElement("P6");
    para6.innerText="We can only build/conduct construction in Germany due to our contracting license.";
    document.body.appendChild(para6);
    
    var para7 = document.createElement("P7");
    para7.innerText="We are available via email (BRArchitects@gmail.com) or via telephone (0871234567).";
    document.body.appendChild(para7);
    
    var para8 = document.createElement("P8");
    para8.innerText="We agree a set fee with our clients so that there are no surprise totals added on top of the agreed fee.";
    document.body.appendChild(para8);
    
    var para9 = document.createElement("P9");
    para9.innerText="We agree a set fee with our clients so that there are no surprise totals added on top of the agreed fee.";
    document.body.appendChild(para9);
    
    var para10 = document.createElement("P10");
    para10.innerText="We here at BR Architects would like to wish all our customers and clients a Happy Christmas!";
    document.body.appendChild(para10);
}

// Removal of 3 Components (divs) //
(function()
{
    document.getElementById('id1','id2','id3','id4').addEventListener("click", RemoveID, false);
}());

function RemoveID() // This will remove the inputs under the "Contact" section when you click on the "name" box //
{
    var myDiv = document.getElementById('id1');
    id1.remove(); // This will remove the Contact section //
    var mySecondDiv = document.getElementById('id2');
    id2.remove(); // This will remove the Contact section //
    var myThirdDiv = document.getElementById('id3');
    id3.remove(); // This will remove the Contact section //
    var myFourthDiv = document.getElementById('id4');
    id4.remove(); // This will remove the Contact section //
}

// Map API Code //
(function()
{
    //Tells the URL where the data is located
    let requestURL = 'R4BQSaRedTt3Q73w8fn-w4QCOahdVU_jdLQcMpwpk34';
            
    //This will create a new request object instance from the XMLHttpRequest constructor
    let request = new XMLHttpRequest(); // This is the fastest way of receiving the code through the server
            
    //Now I have to open the request using the open() method.
    request.open('GET', requestURL); // This means that it will take the code from the link above to display my map
            
    //Now I am setting the responseType to JSON, so that XHR knows that the server will be returning JSON
    request.responseType = 'json';
    request.send();
})()
