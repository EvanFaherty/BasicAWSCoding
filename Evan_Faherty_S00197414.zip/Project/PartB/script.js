"use strict";
// Load my First Endpoint code from location 1 //
fetch('https://api.npoint.io/90fec4785f71982cb441/drivers/0')
    .then(function(resp) {
    return resp.json();
    })
    .then(function(data) {
        console.log(data);
    })

// Load a second Endpoint code from location 2 //
fetch('https://api.npoint.io/3931f35e18c5e1d83702/drivers/0')
    .then(function(resp) {
    return resp.json();
    })
    .then(function(data) {
        console.log(data);
    })